import React from 'react';
import './App.css';

import Slider from './components/Slide';

function App() {
  return (
    <div>
      <Slider />
    </div>
  );
}

export default App;
